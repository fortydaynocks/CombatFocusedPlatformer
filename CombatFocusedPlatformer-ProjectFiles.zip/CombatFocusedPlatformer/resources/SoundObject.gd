extends Resource
class_name SoundObject

@export_category("SoundObject")
@export var audio: AudioStream
@export var tick: int = 1
@export var volume: float = 1
@export var pitch: float = 1
@export var variation: float = 0
