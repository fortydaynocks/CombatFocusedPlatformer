extends Node

#	COLLISION LAYERS
#	Layer 1 = everything
#	Layer 4 = characters
#	Layer 10 = hurtboxes
#	Layer 11 = hitboxes
