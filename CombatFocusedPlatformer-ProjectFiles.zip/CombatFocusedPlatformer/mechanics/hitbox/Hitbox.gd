extends Node2D
class_name Hitbox

@export_category("Hit")
@export var damage: float = 10
@export var hitstop_strength: float = 0.05
@export var hitstop_length: float = 1
@export var hit_cancel: bool = true
@export var hitstun: int = 30

@export_category("Knockback")
@export var knockback: Vector2 = Vector2(5, 5)
@export var additive: bool = false
@export var knockback_relative: bool = true

@export_category("States")
@export var caster_state: String = ""
@export var victim_state: String = ""

@export_category("Detection")
@export var offset: Vector2 = Vector2(0, 0)
@export var size: Vector2 = Vector2(10, 10)
@export var offset_relative: bool = true
@export var max_targets: int = -1
@export_flags_2d_physics var target_layers
@export var hits_caster: bool = false
@export var group: int = 1

@export_category("Timing")
@export var start_tick: int = 0
@export var length: int = 0

@export_category("Audio")
@export var sounds: Array[SoundObject]

var hits = []
var caster = null
var hbox_reference = null
var functional_offset = Vector2(0, 0)

#	--
func create(new_caster):
	hits = []
	
	var hbox = Area2D.new()
	hbox.position = offset
	hbox.set_collision_layer_value(11, true)
	hbox.set_collision_mask_value(4, true)
	hbox.set_collision_mask_value(11, true)
	var shape = CollisionShape2D.new()
	shape.shape = RectangleShape2D.new()
	shape.shape.size = size
	shape.debug_color = Color("ff000064")
	shape.name = "Shape"
	
	new_caster.get_node("HitboxBox").add_child(hbox)
	hbox.add_child(shape)
	
	caster = new_caster
	hbox_reference = hbox
	functional_offset = offset

func clean():
	caster = null
	hits = []
	hbox_reference.queue_free()
	
func disengage():
	if hbox_reference:
		var shape = hbox_reference.get_node("Shape")
		if is_instance_valid(shape): shape.debug_color = Color("ff000064")
	
func detect():
	var hbox = hbox_reference
	var shape = hbox.get_node("Shape")
	if is_instance_valid(shape): shape.debug_color = Color("00ff0064")
	
	#	--	HIT DETECTION
	var found_targets = []
	
	for target in hbox.get_overlapping_bodies():
		if target is ObjectRoot and target not in hits:
			found_targets.append(target)
			hits.append(target)
	
	#	--	CLEANING THE RESULTS
	for target in found_targets:
		if target == caster and hits_caster == false:
			found_targets.erase(target)
	
	return [found_targets, group]

func _tick():
	var hbox = hbox_reference
	if hbox and caster:
		if offset_relative == true:
			functional_offset = Vector2(offset.x * caster.left_right, offset.y)
			hbox.position.x = functional_offset.x
		
