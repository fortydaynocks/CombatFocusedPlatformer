extends Node2D

@export var caster: ObjectRoot
@export var hurtbox: Area2D
