extends CharacterState

@export_category("Run")
@export var run_sound: AudioStream

func _tick():
	super()
	
	if (abs(floor(root.velocity.x)) < root.run_deadzone and root.is_on_floor()) or not (Input.is_action_pressed("Left") or Input.is_action_pressed("Right")):
		self.state_machine.try_change_state("idle")

	if root.is_on_floor() == false:
		root.state_machine.try_change_state("fall")

	if (tick == 1 or tick % 16 == 0) and run_sound:
		root.play_sound(run_sound, 1, 1)
