extends CharacterState
@export_category("Sprint")
@export var dash_speed: float = 300
@export var sprint_sound: AudioStream

func _enter():
	root.surpass_limits = true

func _exit():
	root.surpass_limits = false

func _tick():
	super()
	
	if data != root.input_dir.x or root.input_dir.x == 0:
		root.state_machine.end_state()

	if root.is_on_floor() == false:
		root.state_machine.try_change_state("fall")

	root.velocity.x = root.left_right * dash_speed

	if (tick == 1 or tick % 8 == 0) and sprint_sound:
		root.play_sound(sprint_sound, 1, 2)
