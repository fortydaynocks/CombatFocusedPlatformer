extends ObjectRoot
class_name CharacterRoot

@export_category("Mechanics")
@export var sprint_speed: float = 4
@export var max_jumps: float = 1
@export var jump_power: float = 10
@export var run_speed: float = 2

var jumps = 0
var airtime = 0
var jump_airtime_deadzone = 0.08
var run_deadzone = 45
var input_dir = Vector2(0, 0)

var doing_light_attack = false
var light_attack_stage = 0
var debounce = []

func _tick():
	super()
	
	input_dir = Vector2(0, 0)
	
	#	--	MOVEMENT INPUTS
	if player == true:
		if Input.is_action_pressed("Left"):
			if state_machine.state.can_flip == true or state_machine.state.flip_leniency > state_machine.state.tick:
				left_right = -1
			input_dir.x = -1
			
			apply_force(-self.state_machine.state.strafe, 0)
				
		if Input.is_action_pressed("Right"):
			if state_machine.state.can_flip == true or state_machine.state.flip_leniency > state_machine.state.tick:
				left_right = 1
			input_dir.x = 1
			
			apply_force(self.state_machine.state.strafe, 0)
				
		if Input.is_action_just_pressed("Jump"):
			if state_machine.state.can_jump == true:
				input_dir.y = -1
				
				if airtime <= jump_airtime_deadzone:
					self.state_machine.try_change_state("jump")
				
		if Input.is_action_pressed("Down"):
			input_dir.y = 1
			
			velocity.y += fall_speed * state_machine.state.fastfall
			
		if Input.is_action_just_pressed("Dash"):
			self.state_machine.try_change_state("dash")
		
	#	--	AIRTIME
	if is_on_floor() == false:
		airtime += 1.0/60
		
	else:
		airtime = 0
	
	#	--	FACING DIRECTION
	if player == true:
		if state_machine.state.can_flip == true or state_machine.state.flip_leniency > state_machine.state.tick:
			visuals.scale = Vector2(left_right, 1)
