extends CharacterState

@export_category("Dash")
@export var dash_speed: float = 500

var commit = 0

func _enter():
	root.surpass_limits = true
	commit = root.input_dir.x

func _exit():
	root.surpass_limits = false

func _frame_8():
	if commit != 0:
		root.state_machine.try_change_state("sprint", commit)

func _tick():
	super()
	
	root.velocity.x = root.left_right * dash_speed
	root.velocity.y = 0
