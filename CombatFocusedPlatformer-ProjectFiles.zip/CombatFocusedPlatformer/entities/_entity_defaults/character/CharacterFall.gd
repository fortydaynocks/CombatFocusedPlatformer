extends CharacterState

func _tick():
	super()
	
	if root.is_on_floor() == true:
		root.state_machine.try_change_state("land")
		
