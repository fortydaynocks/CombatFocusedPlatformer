extends ObjectState
class_name CharacterState

@export_category("Modifiers")
@export var can_flip: bool = true
@export var can_jump: bool = true
@export var strafe: float = 20
@export var fastfall: float = 2.0

@export_category("Mechanics")
@export var flip_leniency: int = 0
@export var land_cancel: bool = false

@export_category("Attacks")
@export var l_interrupt: CharacterState
@export var l_window_start: int = 0
@export var l_window_end: int = 0
@export var l_hit_cancel: bool = false
@export var h_interrupt: CharacterState
@export var h_window_start: int = 0
@export var h_window_end: int = 0
@export var h_hit_cancel: bool = false
@export var s_interrupt: CharacterState
@export var s_window_start: int = 0
@export var s_window_end: int = 0
@export var s_hit_cancel: bool = false

var l_button_time = 0
var h_button_time = 0
var s_button_time = 0
var buffer = 2

var was_in_air = false

func _enter():
	super()
	
	was_in_air = false
	l_button_time = 0
	h_button_time = 0
	s_button_time = 0
	

func _tick():
	super()
	
	#	--
	if root.player == true:
		if Input.is_action_pressed("AttackL") and l_interrupt:
			l_button_time += 1
			
			if l_button_time <= buffer:
				if ((tick >= l_window_start or can_hit_cancel == true) and tick <= l_window_end) or (l_window_start == -1 and l_window_end == -1):
					self.state_machine.change_state(l_interrupt.state_name)
		else: l_button_time = 0
				
		if Input.is_action_pressed("AttackH") and h_interrupt:
			h_button_time += 1
			
			if h_button_time <= buffer:
				if ((tick >= h_window_start or can_hit_cancel == true) and tick <= h_window_end) or (h_window_start == -1 and h_window_end == -1):
					self.state_machine.change_state(h_interrupt.state_name)
		else: h_button_time = 0
				
		if Input.is_action_pressed("AttackS") and s_interrupt:
			s_button_time += 1
			
			if s_button_time <= buffer:
				if ((tick >= s_window_start or can_hit_cancel == true) and tick <= s_window_end) or (s_window_start == -1 and s_window_end == -1):
					self.state_machine.change_state(s_interrupt.state_name)
		else: s_button_time = 0
	
	#	--
	if land_cancel == true:
		if was_in_air == true and root.is_on_floor() == true:
			state_machine.change_state("land")
	
	was_in_air = not root.is_on_floor()
