extends CharacterState

@export_category("Jump")
@export var jump_power: float = 400

func _frame_1():
	root.airtime = root.jump_airtime_deadzone
	root.apply_force(0, -jump_power)
