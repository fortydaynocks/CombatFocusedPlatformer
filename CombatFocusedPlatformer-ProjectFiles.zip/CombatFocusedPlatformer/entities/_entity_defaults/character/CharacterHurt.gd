extends CharacterState

@export_category("Hurt")
@export var bounciness: float = 0.75

var stun_left = 0

func _enter():
	super()
	
	stun_left = data.stun_left

func _exit():
	super()

func _tick():
	super()
	
	if stun_left <= 0:
		state_machine.end_state()

	#	--	SURFACE BOUNCE
	if root.is_on_floor():
		root.velocity.y = root.last_velocity.y * -bounciness
	if root.is_on_wall():
		root.velocity.x = root.last_velocity.x * -bounciness
	
	#	--
	stun_left -= 1
