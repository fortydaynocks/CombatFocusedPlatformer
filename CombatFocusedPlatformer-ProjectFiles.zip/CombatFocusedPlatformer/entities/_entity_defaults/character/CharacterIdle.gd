extends CharacterState

func _tick():
	super()
	
	if root.is_on_floor() == true:
			if (abs(floor(root.velocity.x)) >= root.run_deadzone and root.is_on_wall() == false) and (root.player == true and (Input.is_action_pressed("Left") or Input.is_action_pressed("Right"))):
				var dir = 0
				
				root.state_machine.try_change_state("run")
	else:
		root.state_machine.try_change_state("fall")
