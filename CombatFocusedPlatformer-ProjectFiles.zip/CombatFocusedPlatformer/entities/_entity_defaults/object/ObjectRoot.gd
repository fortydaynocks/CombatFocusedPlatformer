extends CharacterBody2D
class_name ObjectRoot

@export_category("Necessities")
@onready var visuals = $"%Visuals"
@onready var sprite = $"%Sprite"
@onready var state_machine = $"%StateMachine"
@onready var sounds = $"%Sounds"

@export var player = false

@export_category("Mechanics")
@export var max_x_speed: float = 200
@export var x_correction_multiplier: float = 0.75
@export var max_y_speed: float = 200
@export var y_correction_multiplier: float = 0.75
@export var fall_speed: float = 10
@export var max_fall_speed: float = 200
@export var push_influence: float = 0.5
@export var friction: float = 0.825
@export var air_friction: float = 0.95
@export var surpass_limits: bool = false

var tick = 0
var left_right = 1

var hitshake = 0
var last_velocity = Vector2(0, 0)

#	--
func apply_force(x, y, relative = false):
	if relative == true: x *= left_right
	velocity.x += x
	velocity.y += y

func set_force(x, y, relative = false):
	if relative == true: x *= left_right
	velocity.x = x
	velocity.y = y

func move_instantly(x, y, relative = false):
	if relative == true: x *= left_right
	position.x += x
	position.y += y

#	--
func _tick():
	tick = state_machine.root_tick
	last_velocity = velocity

	#	--	GRAVITY
	var grav_force = clamp(fall_speed * state_machine.state.gravity, -INF, max_fall_speed)
	velocity.y += grav_force
	
	#	--	FRICTION
	if is_on_floor():
		velocity.x *= (friction * state_machine.state.friction)
	else:
		velocity.x *= (air_friction * state_machine.state.friction)
	
	#	--	PUSH COLLISION
	for c in get_slide_collision_count():
		var cll = get_slide_collision(c)
		var cll_obj = cll.get_collider()
		
		if cll_obj is ObjectRoot and abs(cll.get_normal().y) < 0.9:
			cll_obj.apply_force(velocity.x * cll_obj.push_influence, 0)
	
	#	--	RESULTING MOVEMENT
	if surpass_limits == false:
		if abs(velocity.x) > max_x_speed:
			velocity.x *= x_correction_multiplier
			
		if abs(velocity.y) > max_y_speed:
			velocity.y *= y_correction_multiplier
	
	move_and_slide()

	#	--	FACING DIRECTION
	if player == false:
		if state_machine.state.can_flip == true:
			visuals.scale = Vector2(left_right, 1)
			
	#	--	SURFACE UNSTICK
	#if is_on_floor() == true:
		#velocity.y = 0
	#if is_on_wall() == true:
		#dqvelocity.x = 0
		
func _supertick():
		if hitshake > 0:
			visuals.position = Vector2(randi_range(-hitshake, hitshake), randi_range(-hitshake, hitshake))
			hitshake -= 1


func _got_hit(attacker, hbox):
	pass
	
#	--
func play_sound(sound, volume = 1, pitch = 1):
	var newsound = AudioStreamPlayer2D.new()
	newsound.stream = sound
	newsound.volume_db = volume
	newsound.pitch_scale = pitch
	sounds.add_child(newsound)
	
	newsound.play()
