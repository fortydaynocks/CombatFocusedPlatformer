extends Node
class_name ObjectState

#	--
@onready var root = self.owner
@onready var state_machine = $"%StateMachine"

@export_category("State")
@export var state_name: String = "idle"
@export var state_length: int = -1
@export var return_to_state: ObjectState

@export_category("Animation")
@export var anim_name: String
@export var anim_length: int = 1
@export var ticks_per_sprite: int = 1
@export var loop: bool = false

@export_category("Modifiers")
@export var gravity: float = 1.0
@export var friction: float = 1.0

enum StateTypes {
	Movement,
	LightAttack,
	HeavyAttack,
	Special,
	Defense,
	Hurt,
	Other
}
@export_category("State")
@export var state_type: StateTypes = StateTypes.Other
@export var interruptible: bool = true
@export var self_interruptible: bool = true
@export var force_interrupt: bool = false
@export_multiline var cannot_interrupt_into_types: String = ""
@export_multiline var cannot_interrupt_into_states: String = ""

@export_category("Audio")
@export var sounds: Array[SoundObject]

var data = []
var tick = 0
var sprite_tick = 0

var busy = false
var attacking = false

var hitboxes = []
var hit_something = false
var can_hit_cancel = false
var hits = []

#	--
func update_sprite():
	ticks_per_sprite = clamp(ticks_per_sprite, 0, INF)
	
	if loop == true:
		sprite_tick = clamp((ceil(tick) / ticks_per_sprite) % anim_length, 0, anim_length)
	else:
		sprite_tick = clamp(ceil(tick) / ticks_per_sprite, 0, anim_length)
	
	root.sprite.animation = anim_name
	root.sprite.frame = sprite_tick

#	--
func _enter():
	hit_something = false
	can_hit_cancel = false
	
	hits = []
	
	#	--
	hitboxes = []
	for component in get_children():
		if component is Hitbox:
			component.create(root)
			hitboxes.append(component)

func _tick():
	tick = state_machine.tick
	#	--
	update_sprite()
	
	# 	--
	if state_length > -1:
		if tick > state_length:
			state_machine.change_state(return_to_state.state_name)
			
	#	--	HITBOX FUNCTIONALITY
	for hbox in hitboxes:
		hbox._tick()
		
		if tick >= hbox.start_tick and tick < hbox.start_tick + hbox.length:
			var group = hbox.group
			var result = hbox.detect()
			
			for r in result[0]:
				var should_hit = true
				
				if r == null:
					should_hit = false
					
				if [r, group] in hits:
					should_hit = false
				
				if should_hit == true:
					hits.append([r, group])
					r.call("_got_hit", root, hbox)
					_hit_something(r, hbox)
			
		elif tick >= hbox.start_tick + hbox.length:
			hbox.disengage()
			
	#	--	SOUNDS
	
	for sound in sounds:
		if tick == sound.tick:
			root.play_sound(sound.audio, sound.volume, randf_range(sound.pitch - sound.variation, sound.pitch + sound.variation))
	
func _exit():
	
	#	--
	for hbox in hitboxes:
		hbox.clean()

func _hit_something(something, hbox):
	hit_something = true
	
	if hbox.hit_cancel == true:
		can_hit_cancel = true
	else:
		can_hit_cancel = false
	
	#	--	KNOCKBACK
	var force = hbox.knockback
	if hbox.knockback_relative == true: force.x *= root.left_right
	if hbox.additive == true:
		something.apply_force(force.x, force.y)
	else:
		something.set_force(force.x, force.y)
	
	#	--
	#Engine.time_scale = hbox.hitstop_strength
	#await get_tree().create_timer(hbox.hitstop_length, true, false, true).timeout
	#Engine.time_scale = 1
	
	#	--	LAYERING
	root.z_index = 1
	something.z_index = 0
	
	#	--	SOUNDS
	
	for sound in hbox.sounds:
		root.play_sound(sound.audio, sound.volume, randf_range(sound.pitch - sound.variation, sound.pitch + sound.variation))
	
	#	--	HURT STATES
	var params = {
		"stun_left": hbox.hitstun,
		"attacker": root
	}
	something.state_machine.change_state("hurt", params)
	
	#	--	HITSTOP AND SHAKE
	root.hitshake = hbox.hitstop_length * 25
	something.hitshake = hbox.hitstop_length * 50
	
	await get_tree().create_timer(0.02, true, false, true).timeout
	state_machine.frozen = true
	something.state_machine.frozen = true
	await get_tree().create_timer(hbox.hitstop_length, true, false, true).timeout
	state_machine.frozen = false
	something.state_machine.frozen = false

func _supertick():
		pass
