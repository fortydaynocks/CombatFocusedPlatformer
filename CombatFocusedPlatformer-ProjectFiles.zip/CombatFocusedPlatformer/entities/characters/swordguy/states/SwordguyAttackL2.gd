extends SwordguyAttackState

func _frame_6():
	root.apply_force(100, 0, true)
