extends SwordguyAttackState

func _frame_5():
	root.apply_force(150, 0, true)
