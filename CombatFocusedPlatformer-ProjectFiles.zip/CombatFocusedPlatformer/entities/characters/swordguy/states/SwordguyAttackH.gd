extends SwordguyAttackState

func _frame_7():
	root.apply_force(150, 0, true)
