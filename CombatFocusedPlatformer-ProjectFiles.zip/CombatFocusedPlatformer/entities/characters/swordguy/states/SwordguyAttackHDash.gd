extends SwordguyAttackState

func _frame_1():
	root.surpass_limits = true
	root.apply_force(-100, -300, true)
	
func _frame_16():
	root.surpass_limits = false
	
func _exit():
	super()
	
	root.surpass_limits = false
	
func _tick():
	super()
	
	if tick >= 12 and tick < 16:
		if root.is_on_floor() == true:
			state_machine.tick = 16
		else:
			if tick == 15:
				state_machine.tick = 12
