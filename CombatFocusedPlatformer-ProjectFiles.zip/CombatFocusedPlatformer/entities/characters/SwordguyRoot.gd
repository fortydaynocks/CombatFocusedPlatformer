extends CharacterRoot

func _tick():
	super()
	
	#	--	TEST
	#if is_instance_valid($"%Hitbox"):
	#	for body in $"%Hitbox".get_overlapping_bodies():
	#		if body is ObjectRoot:
	#			if body.get_collision_layer_value(4):
	#				print(body.name)
