extends StateMachine
class_name PlayerStateMachine

@export_category("Player")
@export var player: bool = false

func _physics_process(d):
	super(d)
