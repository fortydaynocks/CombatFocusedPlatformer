extends Node2D
class_name StateMachine

# Used resources:
# https://www.gdquest.com/tutorial/godot/design-patterns/finite-state-machine/

@onready var root = self.owner
@export var entry_state: Node2D
@export var default_state: Node2D
@export var timescale: int = 1

var frozen = false

var states = self.get_children()
var state = null
var last_state = null

var supertick = 0
var root_tick = 0
var tick = 0
var tick_time = 1.0/60.0
var total_delta = 0

#	--
func change_state(new_state, data = null):
	last_state = state
	last_state._exit()
	
	state = self.get_node(new_state)
	if not state: state = default_state
	state.data = data
	state._enter()
	tick = 0
	total_delta = 0
	
func try_change_state(new_state, data = null):
	var new_state_node = self.get_node(new_state)
	if not state or not new_state_node: return
	if state.busy == true: return
	
	#	--
	if state.force_interrupt == true: change_state(new_state, data)
	else:
		if state.interruptible == true:
			if state.state_name == new_state_node.state_name and state.self_interruptible == false: return
			
			change_state(new_state, data)

func end_state():
	if state.return_to_state:
		change_state(state.return_to_state.state_name)
		
	else:
		change_state(default_state.state_name)
	

#	--
func _physics_process(d):
	if not state: state = default_state
	if frozen == true: return
	
	#	--
	states = self.get_children()

	#	--	
	if root and state:
		if total_delta >= tick_time * timescale:
			root._tick()
			state._tick()
			if state.get("_frame_" + str(tick)): state.call("_frame_" + str(tick))
			
			root_tick += 1
			tick += 1
			total_delta = d
		else:
			total_delta += d
	
func _process(d):
	supertick += 1
	
	if root:
		root._supertick()
		
	if state:
		state._supertick()

#	--	STARTING THE MACHINE
func _ready():
	state = entry_state
	
